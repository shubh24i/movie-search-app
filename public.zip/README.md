# movie-search-app
Movie Search App using omdbapi
